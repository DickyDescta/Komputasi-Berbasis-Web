CREATE DATABASE portfolio_db;

USE portfolio_db;

CREATE TABLE pages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    menu_name VARCHAR(255) NOT NULL
);
INSERT INTO pages (title, content, menu_name) VALUES
('Home', 'Selamat datang di portofolio saya.', 'Home'),
('About', 'Saya adalah seorang mahasiswa di Universitas Pembangunan Jaya', 'About'),
('Services', 'Layanan yang saya tawarkan adalah jasa web develop', 'Services'),
('Portfolio', 'Berikut adalah proyek-proyek yang sudah saya kerjakan', 'Portfolio'),
('Contact', 'Hubungi saya di instagram @dickydescta', 'Contact');

UPDATE pages 
SET title = 'Hallo', content = 'Selamat datang di web profil saya' 
WHERE menu_name = 'Home';

UPDATE pages 
SET content = 'Perkenalkan, nama saya Dicky Descta. Saya adalah seorang mahasiswa di Universitas Pembangunan Jaya, di mana saya mengejar gelar di bidang Teknologi Informatika. Di luar studi saya, saya memiliki minat yang besar dalam pengembangan web dan desain grafis. Saya percaya bahwa teknologi dapat menjadi alat yang sangat kuat untuk menyelesaikan masalah dunia nyata, dan saya ingin berkontribusi dalam menciptakan solusi inovatif.'
WHERE menu_name = 'About';

UPDATE pages 
SET content = 'Sebagai seorang pengembang web, saya menawarkan layanan berikut: Desain dan pengembangan situs web responsif, Pengoptimalan SEO untuk meningkatkan visibilitas online, Pembuatan konten yang menarik dan informatif untuk situs web Anda.'
WHERE menu_name = 'Services';

UPDATE pages 
SET title = 'Pendidikan', content = 'Saya lulus dari SMPN 14 Tangerang Selatan pada tahun 2017 dan SMAN 7 Tangerang Selatan pada tahun 2022. Saya memulai perkuliahan saya pada 2023 di Universitas Pembangunan Jaya.'
WHERE menu_name = 'portfolio';

UPDATE pages 
SET content = 'Hubungi saya di instagram'
WHERE menu_name = 'Contact';
ALTER TABLE pages ADD phone_number VARCHAR(20);
UPDATE pages SET phone_number = '081296459934' WHERE menu_name = 'Contact';


