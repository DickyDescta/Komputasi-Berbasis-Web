<?php
$servername = "localhost";
$username = "root"; 
$password = "DDescta22_"; 
$dbname = "portfolio_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query = "SELECT * FROM pages WHERE menu_name = 'Portfolio'";
$result = $conn->query($query);
$row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet"> <!-- Menambahkan font Roboto -->
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Roboto', sans-serif; 
        }

        .hero-image {
            background-image: url('portofolio.jpeg'); 
            background-size: cover; 
            background-position: center;
            height: 100vh; 
            position: relative;
            color: white; 
            display: flex; 
            flex-direction: column; 
            justify-content: center; 
            align-items: center; 
            text-align: center; 
            opacity: 0; 
            animation: fadeIn 1s forwards; 
        }

        nav {
            background-color: black; 
            color: white; 
            z-index: 999; 
        }

        nav a {
            color: white !important;
        }

        .content {
            background: rgba(0, 0, 0, 0); 
            padding: 20px;
            border-radius: 10px; 
            animation: fadeIn 2s ease-in-out;
        }

        footer {
            background-color: black; 
            color: white; 
            text-align: center; 
            padding: 20px 0;
            position: relative; 
            bottom: 0; 
            width: 100%; 
        }

        h2 {
            font-weight: 700; 
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.6); 
            opacity: 0; 
            animation: fadeIn 1s forwards 0.5s; 
        }

        p {
            font-weight: 400; 
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5);
            opacity: 0; 
            animation: fadeIn 1s forwards 1s; 
        }

        @keyframes fadeIn {
            to {
                opacity: 1; 
            }
        }
    </style>
    <title><?php echo htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8'); ?></title>
</head>
<body>
<header>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="logo.png" alt="Logo" style="height: 40px; margin-right: 5px;"> 
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="service.php">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="portofolio.php">Pendidikan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>

    <div class="hero-image">
        <main class="container">
            <h2><?php echo htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8'); ?></h2>
            <p><?php echo htmlspecialchars($row['content'], ENT_QUOTES, 'UTF-8'); ?></p>
        </main>
    </div>

    <footer>
        <p>&copy; 2024 My Portfolio. All rights reserved.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php
$conn->close();
?>
