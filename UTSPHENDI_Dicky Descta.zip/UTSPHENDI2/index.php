<?php
$servername = "localhost";
$username = "root";
$password = "DDescta22_";
$dbname = "portfolio_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query = "SELECT title, content FROM pages WHERE menu_name = 'Home'";
$result = $conn->query($query);
$row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400&display=swap" rel="stylesheet"> <!-- Menambahkan font Roboto -->
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
        }

        .hero-image {
            background-image: url('profileWEB.jpeg'); 
            background-size: cover; 
            background-position: center; 
            height: 100vh; 
            position: relative;
            opacity: 0;
            animation: fadeIn 1s forwards;
        }

        .hero-text {
            font-size: 48px;
            font-weight: bold;
            color: white; 
            text-align: center;
            position: absolute; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%); 
            opacity: 0; 
            animation: fadeIn 1s forwards; 
        }

        .hero-subtext {
            font-size: 24px;
            margin-top: 20px;
            font-family: 'Roboto', sans-serif; 
            font-weight: 300; 
            overflow: hidden; 
            white-space: nowrap; 
            border-right: 3px solid; 
            display: inline-block; 
            animation: typing 4s steps(30, end), blink-caret .75s step-end infinite; 
            color: white; 
        }

        @keyframes fadeIn {
            to {
                opacity: 1; 
            }
        }

        @keyframes typing {
            from {
                width: 0; 
            }
            to {
                width: 100%; 
            }
        }

        @keyframes blink-caret {
            from, to {
                border-color: transparent; 
            }
            50% {
                border-color: white; 
            }
        }

        nav {
            background-color: black;
            color: white; 
            position: absolute; 
            top: 0;
            width: 100%;
            z-index: 999; 
        }

        nav a {
            color: white !important; 
        }

        footer {
            background-color: black; 
            color: white; 
            text-align: center; 
            padding: 20px 0; 
            position: relative; 
            bottom: 0; 
            width: 100%; 
        }
    </style>
    <title>My Portfolio</title>
</head>
<body>
<header>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="logo.png" alt="Logo" style="height: 40px; margin-right: 5px;"> 
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="service.php">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="portofolio.php">Pendidikan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>

    <div class="hero-image">
        <div class="hero-text">
            <?php echo htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8'); ?>
            <br>
            <span class="hero-subtext" id="typewriter-text"><?php echo htmlspecialchars($row['content'], ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 My Portfolio. All rights reserved.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php
$conn->close();
?>
